﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Shop_Inventory_Program
{
    public partial class Form1 : Form
    {
        DataTable allProducts;
        DataTable viewProducts;
        DataTable categories;
        int id = 0;
        string categoryID;
        string productIDToBeEdited;
        //Dictionary<string, int> productIDs = new Dictionary<string, int>();

        public Form1()
        {
            InitializeComponent();
            allProducts = new DataTable();
            viewProducts = new DataTable(); //utk nyimpen hasil filter
            categories = new DataTable();
        }
        private string GenerateIDCategory()
        {
            id++;
            categoryID = "C" + id;
            return categoryID;
        }

        private string FormatIDNumber(int productIDValue)
        {
            if (productIDValue > 9)
            {
                return "0" + productIDValue.ToString();
            } else if (productIDValue > 99)
            {
                return productIDValue.ToString();
            } 

            return "00" + productIDValue.ToString();
        } 

        private string GenerateIDProducts(string productName)
        {
            int counter = 0;
            foreach (DataRow productRow in allProducts.Rows)
            {
                if (productRow["Nama Product"].ToString()[0].ToString().ToLower() == productName[0].ToString().ToLower())
                {
                    counter++;
                }
            }

            return productName[0].ToString().ToUpper() + FormatIDNumber(counter + 1);
            //string frontAlphabet = productName[0].ToString().ToUpper();
            //foreach (KeyValuePair<string, int> productID in productIDs)
            //{
            //    if (frontAlphabet == productID.Key)
            //    {
            //        productIDs[frontAlphabet] += 1;
            //        return frontAlphabet + FormatIDNumber(productIDs[frontAlphabet]);
            //    }
            //}

            //productIDs[frontAlphabet] = 1;

            //return frontAlphabet + FormatIDNumber(productIDs[frontAlphabet]);
        }
        

        private void Form1_Load(object sender, EventArgs e)
        {
            viewProducts.Columns.Add("ID Product");//0
            viewProducts.Columns.Add("Nama Product");//1
            viewProducts.Columns.Add("Harga");//2
            viewProducts.Columns.Add("Stock");//3
            viewProducts.Columns.Add("ID Category");//4

            allProducts.Columns.Add("ID Product");//0
            allProducts.Columns.Add("Nama Product");//1
            allProducts.Columns.Add("Harga");//2
            allProducts.Columns.Add("Stock");//3
            allProducts.Columns.Add("ID Category");//4
            allProducts.Rows.Add("J001", "Jas Hitam", 100000, 10, "C1");
            allProducts.Rows.Add("T001", "T-Shirt Black Pink", 70000, 20, "C2");
            allProducts.Rows.Add("T002", "T-Shirt Obsessive", 75000, 16, "C2");
            allProducts.Rows.Add("R001", "Rok Mini", 82000, 26, "C3");
            allProducts.Rows.Add("J002", "Jeans Biru", 90000, 5, "C4");
            allProducts.Rows.Add("C001", "Celana Pendek Coklat", 60000, 11, "C4");
            allProducts.Rows.Add("C002", "Cawat Blink-Blink", 1000000, 1, "C5");
            allProducts.Rows.Add("R002", "Rocca Shirt", 50000, 8, "C2");

            //productIDs.Add("J", 2);
            //productIDs.Add("T", 2);
            //productIDs.Add("R", 2);
            //productIDs.Add("C", 2);

            categories.Columns.Add("ID Category");
            categories.Columns.Add("Nama Category");
            categories.Rows.Add(GenerateIDCategory(), "Jas");
            categories.Rows.Add(GenerateIDCategory(), "T-shirt");
            categories.Rows.Add(GenerateIDCategory(), "Rok");
            categories.Rows.Add(GenerateIDCategory(), "Celana");
            categories.Rows.Add(GenerateIDCategory(), "Cawat");

            for (int i = 0; i < categories.Rows.Count; i++)
            {
                cbCategory.Items.Add(categories.Rows[i][1]);
            }


            dgvProducts.DataSource = allProducts;
            dgvCategory.DataSource = categories;
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            cbFilter.Enabled = true;
            cbFilter.DataSource = getAllNamaCategory();
        }

        private List<string> getAllNamaCategory()
        {
            List<string> namaCategories = new List<string>();
            foreach (DataRow namaCat in categories.Rows)
            {
                namaCategories.Add(namaCat["Nama Category"].ToString());
            }

            return namaCategories;
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            if (tbNamaProduct.Text.Length < 1 || cbCategory.SelectedItem == null || tbHarga.Text.Length < 1 || tbStock.Text.Length < 1)
            {
                MessageBox.Show("Input harus lengkap");
            }
            else
            {
                allProducts.Rows.Add(GenerateIDProducts(tbNamaProduct.Text), tbNamaProduct.Text, tbHarga.Text, tbStock.Text, AddIDCat());
                tbNamaProduct.Text = "";
                tbHarga.Text = "";
                tbStock.Text = "";
                cbCategory.SelectedItem = null;
                dgvProducts.DataSource = allProducts;
                cbFilter.Enabled = false;
                cbFilter.SelectedIndex = -1;
            }
        }
        private string AddIDCat()
        {
            string tempAddIDCat = "";
            foreach (DataRow row in categories.Rows)
            {
                if (row["Nama Category"].ToString() == cbCategory.Text)
                {
                    tempAddIDCat = row["ID Category"].ToString();
                    break;
                }
            }
            return tempAddIDCat;
        }

        private void btnAddCat_Click(object sender, EventArgs e)
        {            
            if (tbNamaCat.Text.Length < 1)
            {
                MessageBox.Show("Input harus lengkap");                
            }
            else if (CheckCategoryExist() == true)
            {
                MessageBox.Show("Category already exist");
            }
            else
            {
                categories.Rows.Add(GenerateIDCategory(), tbNamaCat.Text);
                cbCategory.Items.Add(tbNamaCat.Text);
                tbNamaCat.Text = "";
            }
        }

        private bool CheckCategoryExist()
        {
            foreach (DataRow namaCat in categories.Rows)
            {
                if (namaCat["Nama Category"].ToString() == tbNamaCat.Text)
                {
                    return true;
                }                
            }
            return false;
        }

        private void btnRemoveCat_Click(object sender, EventArgs e)
        {
            if (dgvCategory.SelectedRows.Count <= 0 || dgvCategory.SelectedRows[0].IsNewRow)
            {
                MessageBox.Show("Harus ada yang dipilih dan yang dipilih tidak boleh row kosongan!");
            }
            else
            {
                DataRow rowToBeRemoved = ((DataRowView)dgvCategory.SelectedRows[0].DataBoundItem).Row;
                removeAllProductsByCatName(rowToBeRemoved["ID Category"].ToString());
                categories.Rows.Remove(rowToBeRemoved);
                dgvProducts.DataSource = allProducts;
                cbFilter.Enabled = false;
                cbFilter.SelectedIndex = -1;
            }
        }

        private void removeAllProductsByCatName(string IDCat)
        {
            allProducts.AcceptChanges();
            foreach (DataRow product in allProducts.Rows)
            {
                if (product["ID Category"].ToString() == IDCat)
                {
                    //allProducts.Rows.Remove(product);
                    product.Delete();
                }
            }
            allProducts.AcceptChanges();
        }

        private void dgvProducts_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvProducts.SelectedRows.Count > 0 && !dgvProducts.SelectedRows[0].IsNewRow)
            {
                DataRow selectedRow = ((DataRowView)dgvProducts.SelectedRows[0].DataBoundItem).Row;

                tbNamaProduct.Text = selectedRow[1].ToString();
                tbHarga.Text = selectedRow[2].ToString();
                tbStock.Text = selectedRow[3].ToString();
                cbCategory.Text = getCategoryName(selectedRow[4].ToString());
                productIDToBeEdited = selectedRow[0].ToString().ToUpper();
            }
        }

        private string getCategoryName(string categoryID)
        {
            foreach (DataRow namaCat in categories.Rows)
            {
                if (namaCat["ID Category"].ToString().ToUpper() == categoryID.ToUpper())
                {
                    return namaCat["Nama Category"].ToString();
                }
            }

            return "";
        }

        private string getCategoryID(string categoryName)
        {
            foreach (DataRow namaCat in categories.Rows)
            {
                if (namaCat["Nama Category"].ToString().ToUpper() == categoryName.ToUpper())
                {
                    return namaCat["ID Category"].ToString();
                }
            }

            return "";
        }

        private void btnEditProduct_Click(object sender, EventArgs e)
        {
            if (tbNamaProduct.Text.Length < 1 || cbCategory.SelectedItem == null || tbHarga.Text.Length < 1 || tbStock.Text.Length < 1)
            {
                MessageBox.Show("Input harus lengkap");
            } else
            {
                int productIndex = getProductToBeEditedRow();
                if (productIndex != -1)
                {
                    if (Int32.Parse(tbStock.Text) > 0) {
                        allProducts.Rows[productIndex][1] = tbNamaProduct.Text;
                        allProducts.Rows[productIndex][2] = tbHarga.Text;
                        allProducts.Rows[productIndex][3] = tbStock.Text;
                        allProducts.Rows[productIndex][4] = getCategoryID(cbCategory.Text);
                    } else
                    {
                        //productIDs[allProducts.Rows[productIndex][1].ToString()[0].ToString().ToUpper()] -= 1;
                        allProducts.Rows.RemoveAt(productIndex);
                    }
                }
                dgvProducts.DataSource = allProducts;
                cbFilter.Enabled = false;
                cbFilter.SelectedIndex = -1;
            }
        }

        private int getProductToBeEditedRow()
        {
            foreach (DataRow product in allProducts.Rows)
            {
                if (product["ID Product"].ToString().ToUpper() == productIDToBeEdited.ToUpper())
                {
                    return allProducts.Rows.IndexOf(product);
                }
            }

            return -1;
        }

        private void btnRemoveProduct_Click(object sender, EventArgs e)
        {
            if (dgvProducts.SelectedRows.Count > 0 && !dgvProducts.SelectedRows[0].IsNewRow)
            {
                DataRow rowToBeRemoved = ((DataRowView)dgvProducts.SelectedRows[0].DataBoundItem).Row;
                //productIDs[rowToBeRemoved["Nama Product"].ToString()[0].ToString().ToUpper()] -= 1;
                removeProductByNama(rowToBeRemoved["Nama Product"].ToString());
                //allProducts.Rows.RemoveAt(allProducts.Rows.IndexOf(rowToBeRemoved));
                dgvProducts.DataSource = allProducts;
                cbFilter.Enabled = false;
                cbFilter.SelectedIndex = -1;
            }
        }

        private void removeProductByNama(string namaProduct)
        {
            foreach (DataRow product in allProducts.Rows)
            {
                if (product["Nama Product"].ToString() == namaProduct)
                {
                    allProducts.Rows.Remove(product);
                    break;
                }
            }
        }

        private void btnAll_Click(object sender, EventArgs e)
        {
            dgvProducts.DataSource = allProducts;
            cbFilter.Enabled = false;
            cbFilter.SelectedIndex = -1;
        }

        private void cbFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbFilter.SelectedIndex != -1)
            {
                filterProductByCategory(cbFilter.Text);
                dgvProducts.DataSource = viewProducts;
            } 
        }

        private void filterProductByCategory(string namaCategory)
        {
            viewProducts.Clear();
            
            string IDCategory = getCategoryID(namaCategory);

            foreach (DataRow productRow in allProducts.Rows)
            {
                if (productRow["ID Category"].ToString() == IDCategory)
                {
                    viewProducts.Rows.Add(productRow.ItemArray);
                }
            }
        }

        private void tbStock_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void tbHarga_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
    }
}
