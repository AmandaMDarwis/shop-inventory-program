﻿namespace Shop_Inventory_Program
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbProduct = new System.Windows.Forms.Label();
            this.btnAll = new System.Windows.Forms.Button();
            this.btnFilter = new System.Windows.Forms.Button();
            this.cbFilter = new System.Windows.Forms.ComboBox();
            this.lbCategory = new System.Windows.Forms.Label();
            this.dgvProducts = new System.Windows.Forms.DataGridView();
            this.dgvCategory = new System.Windows.Forms.DataGridView();
            this.lbDetails = new System.Windows.Forms.Label();
            this.lbNama = new System.Windows.Forms.Label();
            this.lbProductCat = new System.Windows.Forms.Label();
            this.lbHarga = new System.Windows.Forms.Label();
            this.lbStock = new System.Windows.Forms.Label();
            this.tbNamaProduct = new System.Windows.Forms.TextBox();
            this.tbHarga = new System.Windows.Forms.TextBox();
            this.tbStock = new System.Windows.Forms.TextBox();
            this.cbCategory = new System.Windows.Forms.ComboBox();
            this.tbNamaCat = new System.Windows.Forms.TextBox();
            this.lbNamaCat = new System.Windows.Forms.Label();
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.btnEditProduct = new System.Windows.Forms.Button();
            this.btnRemoveProduct = new System.Windows.Forms.Button();
            this.btnAddCat = new System.Windows.Forms.Button();
            this.btnRemoveCat = new System.Windows.Forms.Button();
            this.pbMeme = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProducts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCategory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMeme)).BeginInit();
            this.SuspendLayout();
            // 
            // lbProduct
            // 
            this.lbProduct.AutoSize = true;
            this.lbProduct.Font = new System.Drawing.Font("MS UI Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbProduct.Location = new System.Drawing.Point(60, 21);
            this.lbProduct.Name = "lbProduct";
            this.lbProduct.Size = new System.Drawing.Size(112, 28);
            this.lbProduct.TabIndex = 0;
            this.lbProduct.Text = "Product";
            // 
            // btnAll
            // 
            this.btnAll.Location = new System.Drawing.Point(286, 24);
            this.btnAll.Name = "btnAll";
            this.btnAll.Size = new System.Drawing.Size(68, 33);
            this.btnAll.TabIndex = 1;
            this.btnAll.Text = "All";
            this.btnAll.UseVisualStyleBackColor = true;
            this.btnAll.Click += new System.EventHandler(this.btnAll_Click);
            // 
            // btnFilter
            // 
            this.btnFilter.Location = new System.Drawing.Point(368, 24);
            this.btnFilter.Name = "btnFilter";
            this.btnFilter.Size = new System.Drawing.Size(68, 33);
            this.btnFilter.TabIndex = 2;
            this.btnFilter.Text = "Filter";
            this.btnFilter.UseVisualStyleBackColor = true;
            this.btnFilter.Click += new System.EventHandler(this.btnFilter_Click);
            // 
            // cbFilter
            // 
            this.cbFilter.Enabled = false;
            this.cbFilter.FormattingEnabled = true;
            this.cbFilter.Location = new System.Drawing.Point(449, 28);
            this.cbFilter.Name = "cbFilter";
            this.cbFilter.Size = new System.Drawing.Size(131, 24);
            this.cbFilter.TabIndex = 3;
            this.cbFilter.SelectedIndexChanged += new System.EventHandler(this.cbFilter_SelectedIndexChanged);
            // 
            // lbCategory
            // 
            this.lbCategory.AutoSize = true;
            this.lbCategory.Font = new System.Drawing.Font("MS UI Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCategory.Location = new System.Drawing.Point(671, 21);
            this.lbCategory.Name = "lbCategory";
            this.lbCategory.Size = new System.Drawing.Size(126, 28);
            this.lbCategory.TabIndex = 4;
            this.lbCategory.Text = "Category";
            // 
            // dgvProducts
            // 
            this.dgvProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProducts.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvProducts.Location = new System.Drawing.Point(65, 62);
            this.dgvProducts.Name = "dgvProducts";
            this.dgvProducts.RowHeadersWidth = 51;
            this.dgvProducts.RowTemplate.Height = 24;
            this.dgvProducts.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvProducts.Size = new System.Drawing.Size(515, 301);
            this.dgvProducts.TabIndex = 5;
            this.dgvProducts.SelectionChanged += new System.EventHandler(this.dgvProducts_SelectionChanged);
            // 
            // dgvCategory
            // 
            this.dgvCategory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCategory.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvCategory.Location = new System.Drawing.Point(676, 64);
            this.dgvCategory.Name = "dgvCategory";
            this.dgvCategory.RowHeadersWidth = 51;
            this.dgvCategory.RowTemplate.Height = 24;
            this.dgvCategory.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCategory.Size = new System.Drawing.Size(281, 245);
            this.dgvCategory.TabIndex = 6;
            // 
            // lbDetails
            // 
            this.lbDetails.AutoSize = true;
            this.lbDetails.Font = new System.Drawing.Font("MS UI Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDetails.Location = new System.Drawing.Point(60, 391);
            this.lbDetails.Name = "lbDetails";
            this.lbDetails.Size = new System.Drawing.Size(99, 28);
            this.lbDetails.TabIndex = 7;
            this.lbDetails.Text = "Details";
            // 
            // lbNama
            // 
            this.lbNama.AutoSize = true;
            this.lbNama.Location = new System.Drawing.Point(80, 442);
            this.lbNama.Name = "lbNama";
            this.lbNama.Size = new System.Drawing.Size(50, 16);
            this.lbNama.TabIndex = 8;
            this.lbNama.Text = "Nama :";
            // 
            // lbProductCat
            // 
            this.lbProductCat.AutoSize = true;
            this.lbProductCat.Location = new System.Drawing.Point(62, 473);
            this.lbProductCat.Name = "lbProductCat";
            this.lbProductCat.Size = new System.Drawing.Size(68, 16);
            this.lbProductCat.TabIndex = 9;
            this.lbProductCat.Text = "Category :";
            // 
            // lbHarga
            // 
            this.lbHarga.AutoSize = true;
            this.lbHarga.Location = new System.Drawing.Point(79, 507);
            this.lbHarga.Name = "lbHarga";
            this.lbHarga.Size = new System.Drawing.Size(51, 16);
            this.lbHarga.TabIndex = 10;
            this.lbHarga.Text = "Harga :";
            // 
            // lbStock
            // 
            this.lbStock.AutoSize = true;
            this.lbStock.Location = new System.Drawing.Point(83, 539);
            this.lbStock.Name = "lbStock";
            this.lbStock.Size = new System.Drawing.Size(47, 16);
            this.lbStock.TabIndex = 11;
            this.lbStock.Text = "Stock :";
            // 
            // tbNamaProduct
            // 
            this.tbNamaProduct.Location = new System.Drawing.Point(156, 442);
            this.tbNamaProduct.Name = "tbNamaProduct";
            this.tbNamaProduct.Size = new System.Drawing.Size(424, 22);
            this.tbNamaProduct.TabIndex = 12;
            // 
            // tbHarga
            // 
            this.tbHarga.Location = new System.Drawing.Point(156, 507);
            this.tbHarga.Name = "tbHarga";
            this.tbHarga.Size = new System.Drawing.Size(121, 22);
            this.tbHarga.TabIndex = 13;
            this.tbHarga.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbHarga_KeyPress);
            // 
            // tbStock
            // 
            this.tbStock.Location = new System.Drawing.Point(156, 539);
            this.tbStock.Name = "tbStock";
            this.tbStock.Size = new System.Drawing.Size(121, 22);
            this.tbStock.TabIndex = 14;
            this.tbStock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbStock_KeyPress_1);
            // 
            // cbCategory
            // 
            this.cbCategory.FormattingEnabled = true;
            this.cbCategory.Location = new System.Drawing.Point(156, 473);
            this.cbCategory.Name = "cbCategory";
            this.cbCategory.Size = new System.Drawing.Size(121, 24);
            this.cbCategory.TabIndex = 15;
            // 
            // tbNamaCat
            // 
            this.tbNamaCat.Location = new System.Drawing.Point(742, 320);
            this.tbNamaCat.Name = "tbNamaCat";
            this.tbNamaCat.Size = new System.Drawing.Size(215, 22);
            this.tbNamaCat.TabIndex = 17;
            // 
            // lbNamaCat
            // 
            this.lbNamaCat.AutoSize = true;
            this.lbNamaCat.Location = new System.Drawing.Point(673, 320);
            this.lbNamaCat.Name = "lbNamaCat";
            this.lbNamaCat.Size = new System.Drawing.Size(50, 16);
            this.lbNamaCat.TabIndex = 16;
            this.lbNamaCat.Text = "Nama :";
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnAddProduct.Location = new System.Drawing.Point(349, 507);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(73, 54);
            this.btnAddProduct.TabIndex = 18;
            this.btnAddProduct.Text = "Add Product";
            this.btnAddProduct.UseVisualStyleBackColor = false;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddProduct_Click);
            // 
            // btnEditProduct
            // 
            this.btnEditProduct.BackColor = System.Drawing.Color.Khaki;
            this.btnEditProduct.Location = new System.Drawing.Point(428, 507);
            this.btnEditProduct.Name = "btnEditProduct";
            this.btnEditProduct.Size = new System.Drawing.Size(73, 54);
            this.btnEditProduct.TabIndex = 19;
            this.btnEditProduct.Text = "Edit Product";
            this.btnEditProduct.UseVisualStyleBackColor = false;
            this.btnEditProduct.Click += new System.EventHandler(this.btnEditProduct_Click);
            // 
            // btnRemoveProduct
            // 
            this.btnRemoveProduct.BackColor = System.Drawing.Color.Tomato;
            this.btnRemoveProduct.Location = new System.Drawing.Point(507, 507);
            this.btnRemoveProduct.Name = "btnRemoveProduct";
            this.btnRemoveProduct.Size = new System.Drawing.Size(73, 54);
            this.btnRemoveProduct.TabIndex = 20;
            this.btnRemoveProduct.Text = "Remove Product";
            this.btnRemoveProduct.UseVisualStyleBackColor = false;
            this.btnRemoveProduct.Click += new System.EventHandler(this.btnRemoveProduct_Click);
            // 
            // btnAddCat
            // 
            this.btnAddCat.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnAddCat.Location = new System.Drawing.Point(779, 352);
            this.btnAddCat.Name = "btnAddCat";
            this.btnAddCat.Size = new System.Drawing.Size(86, 54);
            this.btnAddCat.TabIndex = 21;
            this.btnAddCat.Text = "Add Category";
            this.btnAddCat.UseVisualStyleBackColor = false;
            this.btnAddCat.Click += new System.EventHandler(this.btnAddCat_Click);
            // 
            // btnRemoveCat
            // 
            this.btnRemoveCat.BackColor = System.Drawing.Color.Tomato;
            this.btnRemoveCat.Location = new System.Drawing.Point(871, 352);
            this.btnRemoveCat.Name = "btnRemoveCat";
            this.btnRemoveCat.Size = new System.Drawing.Size(86, 54);
            this.btnRemoveCat.TabIndex = 22;
            this.btnRemoveCat.Text = "Remove Category";
            this.btnRemoveCat.UseVisualStyleBackColor = false;
            this.btnRemoveCat.Click += new System.EventHandler(this.btnRemoveCat_Click);
            // 
            // pbMeme
            // 
            this.pbMeme.Image = global::Shop_Inventory_Program.Properties.Resources.programming_meme;
            this.pbMeme.Location = new System.Drawing.Point(676, 434);
            this.pbMeme.Name = "pbMeme";
            this.pbMeme.Size = new System.Drawing.Size(290, 213);
            this.pbMeme.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMeme.TabIndex = 23;
            this.pbMeme.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(1036, 659);
            this.Controls.Add(this.pbMeme);
            this.Controls.Add(this.btnRemoveCat);
            this.Controls.Add(this.btnAddCat);
            this.Controls.Add(this.btnRemoveProduct);
            this.Controls.Add(this.btnEditProduct);
            this.Controls.Add(this.btnAddProduct);
            this.Controls.Add(this.tbNamaCat);
            this.Controls.Add(this.lbNamaCat);
            this.Controls.Add(this.cbCategory);
            this.Controls.Add(this.tbStock);
            this.Controls.Add(this.tbHarga);
            this.Controls.Add(this.tbNamaProduct);
            this.Controls.Add(this.lbStock);
            this.Controls.Add(this.lbHarga);
            this.Controls.Add(this.lbProductCat);
            this.Controls.Add(this.lbNama);
            this.Controls.Add(this.lbDetails);
            this.Controls.Add(this.dgvCategory);
            this.Controls.Add(this.dgvProducts);
            this.Controls.Add(this.lbCategory);
            this.Controls.Add(this.cbFilter);
            this.Controls.Add(this.btnFilter);
            this.Controls.Add(this.btnAll);
            this.Controls.Add(this.lbProduct);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProducts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCategory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMeme)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbProduct;
        private System.Windows.Forms.Button btnAll;
        private System.Windows.Forms.Button btnFilter;
        private System.Windows.Forms.ComboBox cbFilter;
        private System.Windows.Forms.Label lbCategory;
        private System.Windows.Forms.DataGridView dgvProducts;
        private System.Windows.Forms.DataGridView dgvCategory;
        private System.Windows.Forms.Label lbDetails;
        private System.Windows.Forms.Label lbNama;
        private System.Windows.Forms.Label lbProductCat;
        private System.Windows.Forms.Label lbHarga;
        private System.Windows.Forms.Label lbStock;
        private System.Windows.Forms.TextBox tbNamaProduct;
        private System.Windows.Forms.TextBox tbHarga;
        private System.Windows.Forms.TextBox tbStock;
        private System.Windows.Forms.ComboBox cbCategory;
        private System.Windows.Forms.TextBox tbNamaCat;
        private System.Windows.Forms.Label lbNamaCat;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.Button btnEditProduct;
        private System.Windows.Forms.Button btnRemoveProduct;
        private System.Windows.Forms.Button btnAddCat;
        private System.Windows.Forms.Button btnRemoveCat;
        private System.Windows.Forms.PictureBox pbMeme;
    }
}

